import sys
import caffe
import numpy as np
from caffe.proto import caffe_pb2
from google.protobuf import text_format
from caffe import layers as L

debug = False


class Solver:
    def __init__(self, cmd, uid, size, gpus):
        self.cmd = cmd
        self.uid = uid
        self.size = size
        self.gpus = gpus
        self.rank = 0
        self.device = None
        self.caffe = None
        self.buffs = None

    def start(self, rank):
        self.rank = rank

        INFO = 0
        WARNING = 1
        ERROR = 2
        FATAL = 3
        caffe.init_log(WARNING)

        if len(self.gpus) > 0:
            if debug:
                print >> sys.stderr, 'solver gpu ', self.gpus[rank]
            self.device = self.gpus[rank]
            caffe.set_device(self.device)
            caffe.set_mode_gpu()
            caffe.set_solver_count(self.size)
            caffe.set_solver_rank(self.rank)
            caffe.set_multiprocess(True)
        else:
            caffe.set_mode_cpu()

        self.graph = self.solver_graph()
        import tempfile
        with tempfile.NamedTemporaryFile(mode = 'w+', delete = False) as f:
            text_format.PrintMessage(self.graph, f)
            tmp = f.name
        self.caffe = caffe.SGDSolver(tmp)

        if self.uid:
            nccl = caffe.NCCL(self.caffe, self.uid)
            nccl.bcast()
            self.caffe.add_callback(nccl)
            if self.caffe.param.layer_wise_reduce:
                self.caffe.net.after_backward(nccl)

    def write_graph(self, path):
        import tempfile
        f = tempfile.NamedTemporaryFile(mode = 'w+', delete = False)
        text_format.PrintMessage(proto, f)
        f.close()

    def solver_graph(self):
        proto = caffe_pb2.SolverParameter()
        proto.type = self.cmd.solver_type
        if self.device is not None:
            proto.solver_mode = caffe_pb2.SolverParameter.SolverMode.Value(
                'GPU')
            proto.device_id = self.device
        else:
            proto.solver_mode = caffe_pb2.SolverParameter.SolverMode.Value(
                'CPU')
        proto.base_lr = self.cmd.learning_rate
        proto.lr_policy = 'fixed'
        proto.max_iter = int(2e9)
        proto.momentum = self.cmd.momentum
        proto.random_seed = self.cmd.random_seed
        proto.display = 1

        proto.train_net_param.MergeFrom(self.net_def(caffe.TRAIN))
        proto.test_net_param.add().MergeFrom(self.net_def(caffe.TEST))
        proto.test_iter.append(1)
        proto.test_interval = 999999999  # cannot disable or set to 0
        proto.test_initialization = False

        return proto

    def net_def(self, phase):
        if len(self.cmd.sizes) != len(self.cmd.types):
            raise

        n = caffe.NetSpec()
        name = ''

        for i in range(len(self.cmd.types)):
            if self.cmd.types[i] == 'data':
                name = 'data'
                if phase == caffe.TRAIN:
                    n[name], n.label = L.Python(
                        module = 'solver',
                        layer = 'DataLayer',
                        ntop = 2,
                    )
                else:
                    n[name] = L.Python(
                        module = 'solver',
                        layer = 'DataLayer',
                    )

            else:
                fc = L.InnerProduct(
                    n[name],
                    inner_product_param = {'num_output': self.cmd.sizes[i],
                                           'weight_filler': {'type': 'xavier',
                                                             'std': 0.1},
                                           'bias_filler': {'type': 'constant',
                                                           'value': 0}})
                name = 'fc%d' % i
                n[name] = fc

                if self.cmd.types[i] == 'relu':
                    relu = L.ReLU(n[name], in_place = True)
                    name = 'relu%d' % i
                    n[name] = relu
                elif self.cmd.types[i] == 'loss':
                    if phase == caffe.TRAIN:
                        n.loss = L.SoftmaxWithLoss(n[name], n.label)
                else:
                    raise Exception('TODO unsupported: ' + self.cmd.types[i])

        return n.to_proto()


solver = None


class DataLayer(caffe.Layer):
    def setup(self, bottom, top):
        pass

    def reshape(self, bottom, top):
        batch = solver.cmd.batch_size / solver.size
        top[0].reshape(batch, 1, 1, solver.cmd.sizes[0])
        if self.phase == caffe.TRAIN:
            top[1].reshape(batch, 1)

    def forward(self, bottom, top):
        assert len(solver.buffs) == len(top)
        for i in range(len(solver.buffs)):
            assert top[i].data.shape == solver.buffs[i].shape
            top[i].data[...] = solver.buffs[i]

    def backward(self, top, propagate_down, bottom):
        pass


def create(cmd, uid, size, gpus):
    global solver
    solver = Solver(cmd, uid, size, gpus)


def start(rank):
    if debug:
        print >> sys.stderr, 'Starting rank', rank
    solver.start(rank)


def train(batch):
    if debug and solver.rank == 0:
        print >> sys.stderr, 'Train', (batch[0].shape, batch[1].shape)
    solver.buffs = batch
    solver.caffe.step(1)


def predict(batch):
    if debug and solver.rank == 0:
        print >> sys.stderr, 'Predict', batch.shape
    solver.buffs = (batch,)
    res = solver.caffe.test_nets[0].forward()
    res = res.values()[0]
    return res


def save_graph(path):
    if debug:
        print >> sys.stderr, 'Saving graph ', path
    with open(path, 'w+') as f:
        text_format.PrintMessage(solver.graph, f)


def save(path):
    if debug:
        print >> sys.stderr, 'Saving ', path
    solver.caffe.net.save_hdf5(str(path))


def load(path):
    if debug:
        print >> sys.stderr, 'Loading ', path
    solver.caffe.net.load_hdf5(str(path))
