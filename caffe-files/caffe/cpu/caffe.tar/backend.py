#!/usr/bin/env python2
"""
"""

import numpy as np
import struct
from multiprocessing import *

import deepwater_pb2
from solver import *

#gpus = []   # CPU mode
gpus = None #automatic
pool = None
size = 1
batch_size = 0

if gpus is None:
    # Separate process or CUDA fails for later forks
    def get_gpus(pipe):
        try:
            import pycuda.driver as drv
            drv.init()
            cnt = drv.Device.count()
            pipe.send(range(cnt))
            pipe.close()
            print >> sys.stderr, 'Detected', cnt, 'GPUs'
        except Exception:
            print >> sys.stderr, 'No GPU found!'
            pipe.send([])
            pipe.close()


    parent, child = Pipe()
    p = Process(target = get_gpus, args = (child,))
    p.start()
    gpus = parent.recv()
    p.join()

def read_cmd():
    cmd = deepwater_pb2.Cmd()
    size_bytes = sys.stdin.read(4)
    if len(size_bytes) == 0:
        return None
    size = struct.unpack('>I', size_bytes)[0]
    data = sys.stdin.read(size)
    cmd.ParseFromString(data)
    if debug:
        print >> sys.stderr, 'Received', size
    return cmd


def write_cmd(cmd):
    data = cmd.SerializeToString()
    sys.stdout.write(struct.pack('>I', len(data)))
    sys.stdout.write(data)
    sys.stdout.flush()
    if debug:
        print >> sys.stderr, 'Sent', len(data)


if __name__ == '__main__':
    print >> sys.stderr, 'Started Caffe backend'
    while True:
        req = read_cmd()
        if req is None:
            break
        res = deepwater_pb2.Cmd()

        if req.type == deepwater_pb2.Create:
            uid = None

            if not req.use_gpu:
                gpus = []
            if len(gpus) > 0:
                #uid = caffe.NCCL.new_uid()
                size = len(gpus)

            if req.batch_size % size != 0:
                raise Exception('Batch size must be divisible by GPU count')

            pool = Pool(size,
                        initializer = create,
                        initargs = (req, uid, size, gpus))
            pool.map(start, range(size))

            res.type = deepwater_pb2.Success
            batch_size = req.batch_size

        if req.type == deepwater_pb2.Train:
            batch = np.frombuffer(req.data[0], dtype = np.float32)
            label = np.frombuffer(req.data[1], dtype = np.float32)
            batch = batch.reshape((batch_size, 1, 1, len(batch) / batch_size))
            label = label.reshape((batch_size, 1))
            data = zip(np.split(batch, size), np.split(label, size))
            pool.map(train, data)
            res.type = deepwater_pb2.Success

        if req.type == deepwater_pb2.Predict:
            batch = np.frombuffer(req.data[0], dtype = np.float32)
            batch = batch.reshape((batch_size, 1, 1, len(batch) / batch_size))
            data = np.split(batch, size)
            data = pool.map(predict, data)
            data = np.concatenate(data)
            res.data.append(bytes(np.getbuffer(data)))
            res.type = deepwater_pb2.Success

        if req.type == deepwater_pb2.SaveGraph:
            print >> sys.stderr, 'Saving graph to', req.path
            pool.map(save_graph, [req.path])

        if req.type == deepwater_pb2.Save:
            print >> sys.stderr, 'Saving model to', req.path
            pool.map(save, [req.path])

        if req.type == deepwater_pb2.Load:
            print >> sys.stderr, 'Loading model to', req.path
            pool.map(load, [req.path])

        print >> sys.stderr, 'Writing res', res.type
        write_cmd(res)
